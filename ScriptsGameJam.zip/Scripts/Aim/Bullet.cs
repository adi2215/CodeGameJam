using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    private Vector3 shootDir;

    public GameObject destroyAnim;

    public void Setup(Vector3 shootDir)
    {
        this.shootDir = shootDir;
        GameObject aimAngle = GameObject.FindGameObjectWithTag("Gun");
        transform.eulerAngles = new Vector3(0, 0, aimAngle.transform.eulerAngles.z);
        Invoke(nameof(DestroyBullet), 3f);
    }

    private void Update()
    {
        float moveSpeed = 16f;
        transform.position += shootDir * moveSpeed * Time.deltaTime;
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        Target target = col.GetComponent<Target>();
        if (target != null)
        {
            target.Damage();
            DestroyBullet();
        }
    }

    public void DestroyBullet()
    {
        Instantiate(destroyAnim, transform.position, Quaternion.identity);
        Destroy(gameObject);
    }

}
